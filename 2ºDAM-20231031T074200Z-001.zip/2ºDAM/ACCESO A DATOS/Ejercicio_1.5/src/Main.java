public class Main {
    public static void main(String[] args) {
            /*
            *
            * Usando la clase Scanner lee el archivo geografia.csv que contiene una lista de datos sobre posiciones de ciertas localidades y realiza:

            Una clase denominada Localidad con los atributos que aparecen en el archivo csv.
            Crea una clase denominada Mapa que tenga como atributo un HashMap, elige la key mas adecuada y almacena en valor su correspondiente objeto Localidad. No uses constructor y crea los siguientes métodos:
            getters y setters.
            Un método que añada localidades a la colección.
            Sobreescribe el método toString
            Un método que dado el nombre de la localidad nos devuelva un array con la longitud y latitud de la misma.

            Crea una clase de testeo donde:
            Lea el archivo de entrada
            Crea un objeto de tipo Mapa y añada la información obtenida del fichero.
            Muestra su contenido.
            Finalmente, guarde dicho objeto en un fichero de datos.

            * Crea una clase de testeo donde:
            Lea el fichero anterior (dhonde grabó el objeto Mapa)
            Que mediante un Scanner pasa una localidad y obtén la longitud y latitud de la misma, es decir, prueba a realizar búsquedas de localidades sobre el Mapa cargado mostrando la longitud y la latitud.
            *
            *
            *
            *
            *
            *
            * */


    }
}